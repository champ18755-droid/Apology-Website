
  # Apology Website for Disha

  This is a code bundle for Apology Website for Disha. The original project is available at https://www.figma.com/design/VseTq6Ng7NW1XVJN4p7ejD/Apology-Website-for-Disha.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  